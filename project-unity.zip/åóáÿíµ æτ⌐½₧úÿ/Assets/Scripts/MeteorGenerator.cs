using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeteorGenerator : MonoBehaviour
{

    public CharacterController FirstPersonController;
    public Transform Meteor;
    public float scalefactor;

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            scalefactor = Random.Range(2.0f, 10.0f);     //for radius (1.0,5.0)
            Meteor.transform.localScale = new Vector3(scalefactor, scalefactor, scalefactor);
            Instantiate(Meteor, FirstPersonController.transform.position, Quaternion.identity);
        }
    }
}
