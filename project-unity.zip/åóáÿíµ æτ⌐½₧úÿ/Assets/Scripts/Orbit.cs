using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Orbit : MonoBehaviour
{
    public GameObject Sun;
    
    void Update()
    {
        transform.RotateAround(Sun.transform.position, Vector3.up, 20 * Time.deltaTime);
    }
}
