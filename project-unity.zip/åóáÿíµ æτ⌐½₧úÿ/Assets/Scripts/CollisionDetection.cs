using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollisionDetection : MonoBehaviour
{

    public Transform Meteor;

    void OnCollisionEnter(Collision collision)
    { 
        if (collision.gameObject.name == "Planet1")
        {
            for (int i = 0; i < 10; i++)
            {
                Meteor.transform.localScale = new Vector3(1, 1, 1);
                Instantiate(Meteor, collision.gameObject.transform.position, Quaternion.identity);
                Meteor.transform.Translate(new Vector3(Random.Range(-200f,200f) * Time.deltaTime, Random.Range(-200f, 200f) * Time.deltaTime, Random.Range(-200f, 200f) * Time.deltaTime));
            } 
            Destroy(collision.gameObject);
            Destroy(this.gameObject);
            Debug.Log("Planet1 - Entered called.");
        }
        else if (collision.gameObject.name == "Planet2")
        {
            for (int i = 0; i < 10; i++)
            {
                Meteor.transform.localScale = new Vector3(1, 1, 1);
                Instantiate(Meteor, collision.gameObject.transform.position, Quaternion.identity);
                Meteor.transform.Translate(new Vector3(Random.Range(-200f, 200f) * Time.deltaTime, Random.Range(-200f, 200f) * Time.deltaTime, Random.Range(-200f, 200f) * Time.deltaTime));
            }
            Destroy(collision.gameObject);
            Destroy(this.gameObject);
            Debug.Log("Planet2 - Entered called.");
        }
        else if (collision.gameObject.name == "Planet3")
        {
            for (int i = 0; i < 10; i++)
            {
                Meteor.transform.localScale = new Vector3(1, 1, 1);
                Instantiate(Meteor, collision.gameObject.transform.position, Quaternion.identity);
                Meteor.transform.Translate(new Vector3(Random.Range(-200f, 200f) * Time.deltaTime, Random.Range(-200f, 200f) * Time.deltaTime, Random.Range(-200f, 200f) * Time.deltaTime));
            }
            Destroy(collision.gameObject);
            Destroy(this.gameObject);
            Debug.Log("Planet3 - Entered called.");
        }
        else if (collision.gameObject.name == "Planet4")
        {
            for (int i = 0; i < 10; i++)
            {
                Meteor.transform.localScale = new Vector3(1, 1, 1);
                Instantiate(Meteor, collision.gameObject.transform.position, Quaternion.identity);
                Meteor.transform.Translate(new Vector3(Random.Range(-200f, 200f) * Time.deltaTime, Random.Range(-200f, 200f) * Time.deltaTime, Random.Range(-200f, 200f) * Time.deltaTime));
            }
            Destroy(collision.gameObject);
            Destroy(this.gameObject);
            Debug.Log("Planet4 - Entered called.");
        }
        else if (collision.gameObject.name == "Planet5")
        {
            for (int i = 0; i < 10; i++)
            {
                Meteor.transform.localScale = new Vector3(1, 1, 1);
                Instantiate(Meteor, collision.gameObject.transform.position, Quaternion.identity);
                Meteor.transform.Translate(new Vector3(Random.Range(-200f, 200f) * Time.deltaTime, Random.Range(-200f, 200f) * Time.deltaTime, Random.Range(-200f, 200f) * Time.deltaTime));
            }
            Destroy(collision.gameObject);
            Destroy(this.gameObject);
            Debug.Log("Planet5 - Entered called.");
        }
    }
}
