using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMovement : MonoBehaviour
{

    public float speed = 25f;
    public GameObject MainCamera;

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D))        //kinisi deksia,x axis me D,deksio belaki
        {
            transform.Translate(new Vector3(speed * Time.deltaTime, 0, 0));
        }
        if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A))
        {
            transform.Translate(new Vector3(-speed * Time.deltaTime, 0, 0));    //kinisi aristera,x axis me A,aristero belaki
        }
        if (Input.GetKey(KeyCode.Z))
        {
            transform.Translate(new Vector3(0, -speed * Time.deltaTime, 0));       //kinisi kato,y axis me to Z
        }
        if (Input.GetKey(KeyCode.Q))
        {
            transform.Translate(new Vector3(0, speed * Time.deltaTime, 0));        //kinisi pano,y axis me to Q
        }

        if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow))
        {
            transform.position += MainCamera.transform.forward * speed * Time.deltaTime;    //kinisi mposta me W,pano belaki
        }
        if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow))
        {
            transform.position -= MainCamera.transform.forward * speed * Time.deltaTime;    //kinisi piso me S,kato belaki
        }
    }
}
