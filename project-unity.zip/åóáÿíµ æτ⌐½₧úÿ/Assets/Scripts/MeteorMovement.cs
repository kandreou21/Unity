using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeteorMovement : MonoBehaviour
{

    public Transform meteor;
    public GameObject MainCamera;
    public float meteorSpeed = 150f;

    // Update is called once per frame
    void Update()
    {
        meteor.transform.position += MainCamera.transform.forward * meteorSpeed * Time.deltaTime;
    }
}